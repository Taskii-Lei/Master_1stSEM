sudo cp keys/cnlab.cert /usr/local/share/ca-certificates/cnlab.crt
sudo update-ca-certificates